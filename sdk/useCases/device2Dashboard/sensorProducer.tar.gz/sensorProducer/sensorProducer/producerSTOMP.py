import sys, os, json
from stompest.config import StompConfig
from stompest.sync import Stomp

configFile = open(os.path.dirname(os.path.realpath(__file__)) + "/producer.config")
configData = json.load(configFile)
configFile.close()
deviceID = configData["deviceID"]
coordinate = configData["coordinate"]
server = configData["broker"]["host"]
vhost = configData["broker"]["vhost"]
username = configData["broker"]["username"]
password = configData["broker"]["password"]

def connect():
	try:
		client = Stomp(StompConfig("tcp://" + server + ":61613", login = username, passcode = password, version = "1.2"))
		client.connect(host = vhost)
		return client
	except:
		print "Error: Failed to connect broker"

client = connect() #connect to broker

#publish message
def send(msgJson, type = "sensors"):
	global client
	msgJson["deviceID"] = deviceID
	msgJson["coordinate"] = coordinate
	try:
		client.send("/topic/" + type, json.dumps(msgJson, ensure_ascii=False), {"content-type": "application/json"})
	except:
		print "Error: Failed to send message"
		client = connect() #reconnect to broker
