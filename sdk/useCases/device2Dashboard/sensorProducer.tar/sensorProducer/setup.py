from setuptools import setup, find_packages
import sys, os

def read(filename):
    return open(os.path.join(os.path.dirname(__file__), filename)).read()

if sys.version_info[:2] < (2, 6):
    print 'sensorProducer requires Python version 2.6 or later (%s detected).' % '.'.join(sys.version_info[:2])
    sys.exit(-1)
if sys.version_info[:2] >= (3, 0):
    print 'sensorProducer is not yet compatible with Python 3 (%s detected).' % '.'.join(sys.version_info[:2])
    sys.exit(-1)

setup(
    name='sensorProducer',
    version='0.2.0',
    description='Producer module for sensor analytics application over robomq.io',
    url='https://github.com/robomq/robomq.io',
    author='SRB Technologies',
    author_email='bramh.gupta@robomq.io',
	packages=find_packages(),
    namespace_packages=['sensorProducer'],
    long_description=read('README'),
	package_data={
        'sensorProducer': ['producer.config'],
    },
    install_requires=['pika', 'paho-mqtt', 'stompest'],
)
