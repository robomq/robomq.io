import sys, os, json, pika

configFile = open(os.path.dirname(os.path.realpath(__file__)) + "/producer.config")
configData = json.load(configFile)
configFile.close()
deviceID = configData["deviceID"]
coordinate = configData["coordinate"]
server = configData["broker"]["host"]
vhost = configData["broker"]["vhost"]
username = configData["broker"]["username"]
password = configData["broker"]["password"]

def connect():
	try:
		parameters = pika.URLParameters("amqp://" + username + ":" + password + "@" + server + ":5672/" + vhost)
		connection = pika.BlockingConnection(parameters)
		channel = connection.channel()
		return channel
	except:
		print "Error: Failed to connect broker"

channel = connect() #connect to broker

#publish message
def send(msgJson, type = "sensors"):
	global channel
	msgJson["deviceID"] = deviceID
	msgJson["coordinate"] = coordinate
	properties = pika.BasicProperties(content_type = "application/json", delivery_mode = 1)
	try:
		channel.basic_publish("amq.topic", type, json.dumps(msgJson, ensure_ascii=False), properties)
	except:
		print "Error: Failed to send message"
		channel = connect() #reconnect to broker
