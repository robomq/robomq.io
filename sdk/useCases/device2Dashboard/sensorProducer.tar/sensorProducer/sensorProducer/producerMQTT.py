import sys, os, json
import paho.mqtt.client as mqtt

configFile = open(os.path.dirname(os.path.realpath(__file__)) + "/producer.config")
configData = json.load(configFile)
configFile.close()
deviceID = configData["deviceID"]
coordinate = configData["coordinate"]
server = configData["broker"]["host"]
vhost = configData["broker"]["vhost"]
username = configData["broker"]["username"]
password = configData["broker"]["password"]

def connect():
	try:
		client = mqtt.Client(client_id="", clean_session=True, userdata=None, protocol="MQTTv31")
		client.username_pw_set(vhost + ":" + username, password)
		client.connect(server, 1883, keepalive=60, bind_address="")
		client.loop_start() #start network loop
		return client
	except:
		print "Error: Failed to connect broker"

def reconnect():
	global client
	if (client):
		client.loop_stop() #stop the current loop before reconnecting
		client.disconnect()
	client = connect()

client = connect() #connect to broker

#publish message
def send(msgJson, type = "sensors"):
	global client
	msgJson["deviceID"] = deviceID
	msgJson["coordinate"] = coordinate
	try:
		result = client.publish(type, payload=str(json.dumps(msgJson, ensure_ascii=False)), qos=1, retain=False)
		if (result[0] == 4):
			reconnect() #reconnect to broker
	except:
		print "Error: Failed to send message"
		reconnect() #reconnect to broker
